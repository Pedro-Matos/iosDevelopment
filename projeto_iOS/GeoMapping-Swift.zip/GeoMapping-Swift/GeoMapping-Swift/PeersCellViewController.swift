//
//  PeersCellViewController.swift
//  GeoMapping-Swift
//
//  Created by Pedro Ferreira de Matos on 25/05/17.
//  Copyright © 2017 Pedro Ferreira de Matos. All rights reserved.
//

import UIKit

class PeersCellViewController: UITableViewCell {
    
    //MARK: Properties

    
    
    @IBOutlet weak var peerID_label: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}
